from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from django.shortcuts import get_object_or_404
from .models import Student, Attendance, Course, Department, Batch, Subject
from .serializers import StudentSerializer, AttendanceSerializer
import datetime

# ViewSet for Student model
class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

    # Retrieve student by roll number
    @action(detail=False, methods=['get'], url_path='roll-number/(?P<roll_number>[^/.]+)')
    def get_by_roll_number(self, request, roll_number=None):
        student = get_object_or_404(Student, roll_number=roll_number)
        serializer = self.get_serializer(student)
        return Response(serializer.data)

    # Retrieve all students by batch, course, department
    @action(detail=False, methods=['get'], url_path='batch/(?P<batch_id>\d+)/course/(?P<course_id>\d+)/department/(?P<department_id>\d+)')
    def get_by_batch_course_department(self, request, batch_id=None, course_id=None, department_id=None):
        students = Student.objects.filter(batch_id=batch_id, course_id=course_id, department_id=department_id)
        serializer = self.get_serializer(students, many=True)
        return Response(serializer.data)

# ViewSet for Attendance model
class AttendanceViewSet(viewsets.ModelViewSet):
    queryset = Attendance.objects.all()
    serializer_class = AttendanceSerializer

    # Mark attendance by student roll number
    @action(detail=False, methods=['post'], url_path='mark-by-roll-number')
    def mark_attendance_by_roll_number(self, request):
        roll_number = request.data.get('roll_number')
        is_present = request.data.get('is_present', True)

        student = get_object_or_404(Student, roll_number=roll_number)
        attendance, created = Attendance.objects.get_or_create(student=student, date=datetime.date.today())
        attendance.is_present = is_present
        attendance.save()

        return Response({'status': 'attendance marked', 'is_present': attendance.is_present})

    # Get attendance for a specific student by roll number
    @action(detail=False, methods=['get'], url_path='student/(?P<roll_number>[^/.]+)')
    def get_attendance_by_roll_number(self, request, roll_number=None):
        student = get_object_or_404(Student, roll_number=roll_number)
        attendance = Attendance.objects.filter(student=student)
        serializer = self.get_serializer(attendance, many=True)
        return Response(serializer.data)

# Additional viewset to handle Course, Department, Batch, Subject if needed
class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.all()
    serializer_class = serializers.ModelSerializer

class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = serializers.ModelSerializer

class BatchViewSet(viewsets.ModelViewSet):
    queryset = Batch.objects.all()
    serializer_class = serializers.ModelSerializer

class SubjectViewSet(viewsets.ModelViewSet):
    queryset = Subject.objects.all()
    serializer_class = serializers.ModelSerializer

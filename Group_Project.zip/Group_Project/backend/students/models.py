from django.db import models

# Model to represent Departments (e.g., Computer Science, Mathematics)
class Department(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.name

# Model to represent Courses (e.g., B.Tech, M.Sc)
class Course(models.Model):
    name = models.CharField(max_length=100)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    duration_years = models.IntegerField()  # Duration of the course in years

    def __str__(self):
        return self.name

# Model to represent Batches (e.g., 2020-2024 batch)
class Batch(models.Model):
    start_year = models.IntegerField()
    end_year = models.IntegerField()
    course = models.ForeignKey(Course, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.start_year} - {self.end_year}'

# Model to represent Students and their details
class Student(models.Model):
    name = models.CharField(max_length=255)
    roll_number = models.CharField(max_length=20, unique=True)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15)
    address = models.TextField()
    id_card_number = models.CharField(max_length=20, unique=True)
    hostel_status = models.BooleanField(default=False)  # Whether the student is in hostel or not
    face_id = models.ImageField(upload_to='students/faces/')  # Store the student's face image for recognition
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.name} ({self.roll_number})'

# Model to represent Attendance using face recognition
class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    is_present = models.BooleanField(default=False)  # Marked true if face is recognized

    def __str__(self):
        return f'Attendance for {self.student.name} on {self.date}'

# Model to represent Subjects
class Subject(models.Model):
    name = models.CharField(max_length=100)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    semester = models.IntegerField()

    def __str__(self):
        return self.name

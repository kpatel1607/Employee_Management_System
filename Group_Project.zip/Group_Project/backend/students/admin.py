from django.contrib import admin
from .models import Department, Course, Batch, Student, Attendance, Subject

admin.site.register(Department)
admin.site.register(Course)
admin.site.register(Batch)
admin.site.register(Student)
admin.site.register(Attendance)
admin.site.register(Subject)

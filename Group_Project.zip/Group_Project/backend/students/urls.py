from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StudentViewSet, AttendanceViewSet, CourseViewSet, DepartmentViewSet, BatchViewSet, SubjectViewSet

# Initialize the DRF router
router = DefaultRouter()
router.register(r'students', StudentViewSet)  # Registers /students/ endpoints
router.register(r'attendance', AttendanceViewSet)  # Registers /attendance/ endpoints
router.register(r'courses', CourseViewSet)  # Registers /courses/ endpoints
router.register(r'departments', DepartmentViewSet)  # Registers /departments/ endpoints
router.register(r'batches', BatchViewSet)  # Registers /batches/ endpoints
router.register(r'subjects', SubjectViewSet)  # Registers /subjects/ endpoints

urlpatterns = [
    path('', include(router.urls)),  # Includes all API endpoints from the router
]
